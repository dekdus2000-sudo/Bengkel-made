# Bengkel Made Android

Aplikasi Android pembungkus Bengkel Made dan penerima menu Bagikan untuk PDF, foto, video, dokumen, dan teks.

- Tampil sebagai **Bengkel Made** pada menu Bagikan Android.
- Menerima maksimal 5 berkas sekaligus, masing-masing maksimal 25 MB.
- Menyalin berkas ke penyimpanan sementara aplikasi agar izin file dari My Bisnis/Galeri tidak hilang.
- Memasukkan berkas ke antrean IndexedDB `bm-share-v1`; halaman Bagikan Cepat memprosesnya saat internet tersedia.
- Memuat ulang otomatis ketika jaringan kembali aktif.

Build otomatis tersedia melalui GitHub Actions. Hasilnya bernama `Bengkel-Made-APK`.

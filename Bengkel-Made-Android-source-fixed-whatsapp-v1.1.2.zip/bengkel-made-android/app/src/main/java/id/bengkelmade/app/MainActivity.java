package id.bengkelmade.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.ActivityNotFoundException;
import android.widget.ProgressBar;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String BASE_URL = "https://bengkel-made.dekdus2000.chatgpt.site/";
    private static final String LOCAL_HOST = "https://bengkel-made.local/share/";
    private final Map<String, SharedFile> pending = new LinkedHashMap<>();
    private WebView web;
    private ProgressBar progress;
    private String sharedText = "";
    private boolean shareWaiting;

    private static class SharedFile {
        final File file;
        final String name;
        final String mime;
        SharedFile(File file, String name, String mime) {
            this.file = file; this.name = name; this.mime = mime;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        setContentView(web);
        addContentView(progress, new android.view.ViewGroup.LayoutParams(96, 96));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Bridge(), "BengkelMade");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handleExternalUrl(r.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handleExternalUrl(url);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (!url.startsWith(LOCAL_HOST)) return super.shouldInterceptRequest(view, request);
                SharedFile item;
                synchronized (pending) {
                    item = pending.get(url.substring(LOCAL_HOST.length()));
                }
                if (item == null) return emptyResponse(404);
                try {
                    Map<String, String> headers = new HashMap<>();
                    // fetch() berjalan dari origin chatgpt.site, sedangkan file lokal memakai
                    // origin bengkel-made.local. Tanpa header CORS, WebView memblokir response
                    // walaupun request sudah berhasil di-intercept oleh aplikasi.
                    headers.put("Access-Control-Allow-Origin", BASE_URL.substring(0, BASE_URL.length() - 1));
                    headers.put("Access-Control-Allow-Methods", "GET, OPTIONS");
                    headers.put("Access-Control-Allow-Headers", "*");
                    headers.put("Cache-Control", "no-store");
                    headers.put("Content-Disposition", "inline; filename=\"" + safeHeader(item.name) + "\"");
                    return new WebResourceResponse(item.mime, null, 200, "OK", headers,
                        new FileInputStream(item.file));
                } catch (Exception e) { return emptyResponse(500); }
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                if (shareWaiting && url.startsWith(BASE_URL)) injectShare();
            }
        });
        loadQueue();
        registerNetworkRetry();
        openIntent(getIntent());
    }

    private boolean handleExternalUrl(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        if (scheme == null || "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
        try {
            Intent intent;
            if (url.startsWith("intent://")) {
                intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    String fallback = intent.getStringExtra("browser_fallback_url");
                    if (fallback != null && !fallback.isEmpty()) web.loadUrl(fallback);
                    else Toast.makeText(this, "Aplikasi tujuan belum terpasang", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Tidak dapat membuka aplikasi tujuan", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    private WebResourceResponse emptyResponse(int code) {
        return new WebResourceResponse("text/plain", "UTF-8", code, "Unavailable",
            new java.util.HashMap<>(), new java.io.ByteArrayInputStream(new byte[0]));
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        openIntent(intent);
    }

    private void openIntent(Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action) || Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            cleanupPending();
            sharedText = value(intent.getStringExtra(Intent.EXTRA_TEXT));
            ArrayList<Uri> uris = new ArrayList<>();
            Uri one = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            ArrayList<Uri> many = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (one != null) uris.add(one);
            if (many != null) uris.addAll(many);
            int limit = Math.min(5, uris.size());
            for (int i = 0; i < limit; i++) copySharedUri(uris.get(i));
            shareWaiting = !pending.isEmpty() || !sharedText.isEmpty();
            saveQueue();
            Toast.makeText(this, shareWaiting ? "Bagikan Cepat diterima" : "File tidak dapat dibaca", Toast.LENGTH_SHORT).show();
        }
        progress.setVisibility(View.VISIBLE);
        web.loadUrl(BASE_URL);
    }

    private void copySharedUri(Uri uri) {
        try {
            ContentResolver resolver = getContentResolver();
            String name = displayName(uri);
            String mime = resolver.getType(uri);
            if (mime == null) mime = guessMime(name);
            String token = UUID.randomUUID().toString();
            File target = new File(getCacheDir(), "share-" + token);
            try (InputStream in = resolver.openInputStream(uri); FileOutputStream out = new FileOutputStream(target)) {
                if (in == null) return;
                byte[] buffer = new byte[64 * 1024]; int n; long total = 0;
                while ((n = in.read(buffer)) >= 0) {
                    total += n;
                    if (total > 25L * 1024L * 1024L) throw new IllegalArgumentException("File melebihi 25 MB");
                    out.write(buffer, 0, n);
                }
            }
            synchronized (pending) {
                pending.put(token, new SharedFile(target, name, mime));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Gagal membaca satu file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void injectShare() {
        shareWaiting = false;
        StringBuilder files = new StringBuilder("[");
        int i = 0;
        for (Map.Entry<String, SharedFile> entry : pending.entrySet()) {
            if (i++ > 0) files.append(',');
            SharedFile f = entry.getValue();
            files.append("{url:").append(JSONObject.quote(LOCAL_HOST + entry.getKey()))
                 .append(",name:").append(JSONObject.quote(f.name))
                 .append(",type:").append(JSONObject.quote(f.mime)).append('}');
        }
        files.append(']');
        String script = "(async()=>{try{" +
            "const meta=" + files + ";const fs=[];" +
            "for(const m of meta){const r=await fetch(m.url,{cache:'no-store'});if(!r.ok)throw new Error('HTTP '+r.status+' '+m.name);const b=await r.blob();fs.push(new File([b],m.name,{type:m.type||b.type||'application/octet-stream'}));}" +
            "const d=await new Promise((ok,fail)=>{const q=indexedDB.open('bm-share-v1',1);q.onupgradeneeded=()=>{if(!q.result.objectStoreNames.contains('inbox'))q.result.createObjectStore('inbox',{keyPath:'key'})};q.onsuccess=()=>ok(q.result);q.onerror=()=>fail(q.error||new Error('IndexedDB gagal dibuka'));});" +
            "await new Promise((ok,fail)=>{const t=d.transaction('inbox','readwrite');t.objectStore('inbox').put({key:'latest',files:fs,title:'Android',text:" + JSONObject.quote(sharedText) + ",url:'',receivedAt:new Date().toISOString()});t.oncomplete=ok;t.onerror=()=>fail(t.error||new Error('IndexedDB gagal menyimpan'));t.onabort=()=>fail(t.error||new Error('IndexedDB dibatalkan'));});" +
            "BengkelMade.confirmSaved();location.replace('/?shared=1');" +
            "}catch(e){BengkelMade.shareFailed(String(e&&e.message||e));}})();";
        web.evaluateJavascript(script, null);
    }

    private void registerNetworkRetry() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        cm.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                runOnUiThread(() -> { if (web != null && web.getUrl() != null) web.reload(); });
            }
        });
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return value(c.getString(0));
        } catch (Exception ignored) {}
        String last = uri.getLastPathSegment();
        return last == null ? "bagikan-file" : last;
    }

    private String guessMime(String name) {
        String ext = MimeTypeMap.getFileExtensionFromUrl(name);
        String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext == null ? "" : ext.toLowerCase());
        return type == null ? "application/octet-stream" : type;
    }

    private String value(String x) { return x == null ? "" : x; }

    private String safeHeader(String x) {
        return value(x).replace("\r", "").replace("\n", "").replace("\"", "'");
    }

    private class Bridge {
        @JavascriptInterface public void confirmSaved() {
            runOnUiThread(() -> cleanupPending());
        }
        @JavascriptInterface public void shareFailed(String message) {
            runOnUiThread(() -> {
                shareWaiting = true; // jangan hapus antrean; pengguna bisa mencoba lagi
                Toast.makeText(MainActivity.this,
                    "Bagikan Cepat gagal: " + value(message), Toast.LENGTH_LONG).show();
            });
        }
    }

    private void saveQueue() {
        try {
            JSONArray rows = new JSONArray();
            for (Map.Entry<String, SharedFile> entry : pending.entrySet()) {
                JSONObject row = new JSONObject();
                row.put("token", entry.getKey());
                row.put("path", entry.getValue().file.getAbsolutePath());
                row.put("name", entry.getValue().name);
                row.put("mime", entry.getValue().mime);
                rows.put(row);
            }
            getPreferences(MODE_PRIVATE).edit()
                .putString("files", rows.toString()).putString("text", sharedText).apply();
        } catch (Exception ignored) {}
    }

    private void loadQueue() {
        try {
            JSONArray rows = new JSONArray(getPreferences(MODE_PRIVATE).getString("files", "[]"));
            sharedText = getPreferences(MODE_PRIVATE).getString("text", "");
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.getJSONObject(i);
                File file = new File(row.getString("path"));
                if (file.isFile()) pending.put(row.getString("token"),
                    new SharedFile(file, row.getString("name"), row.getString("mime")));
            }
            shareWaiting = !pending.isEmpty() || !sharedText.isEmpty();
        } catch (Exception ignored) {}
    }

    private void cleanupPending() {
        synchronized (pending) {
            for (SharedFile item : pending.values()) item.file.delete();
            pending.clear();
        }
        sharedText = "";
        getPreferences(MODE_PRIVATE).edit().clear().apply();
    }
    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
